import Image from 'next/image'
import Timeline from '../components/Timeline'

export default function Home() {
  return (
    <>
      <Timeline />
    </>
  )
}
